# Procedural Motion Mechanics

Read only the section selected by `SKILL.md`. These mechanisms target Three.js
r185 `WebGPURenderer` and TSL.

## Time and state models

### Closed-form interpolation

Choose interpolation from boundary conditions:

| Boundary condition | Representation |
| --- | --- |
| endpoint position and velocity | cubic Hermite |
| rest-to-rest position with continuous acceleration | quintic minimum jerk |
| constant speed on a curved path | arc-length table with monotone inversion and an error bound |
| constant angular speed between orientations | quaternion `slerp`, with shortest or declared long arc |
| multi-key orientation with first-derivative continuity | sign-continuous `squad` |
| coupled rotation and translation | screw/SE(3) interpolation with a declared frame convention |

### Fixed-step presentation

One owner holds raw delta, clamped delta, fixed step, maximum substeps,
accumulator, simulation time, timeline time, separate debt state, and pause/resume
policy:

```text
substeps = 0
debtDecision = none
clampedDelta = min(rawDelta, maxFrameDelta)
clampDebt = rawDelta - clampedDelta
accumulator += clampedDelta
while accumulator >= fixedStep and substeps < maxSubsteps:
  previous = valueCopy(current)
  current = step(current, fixedStep, simulationTime + fixedStep)
  simulationTime += fixedStep
  accumulator -= fixedStep
  substeps += 1

if accumulator >= fixedStep:
  wholeStepDebt = floor(accumulator / fixedStep) * fixedStep
  accumulator -= wholeStepDebt
  clampDebt += wholeStepDebt

if clampDebt > 0:
  debtDecision = recordCatchUpExplicitTimeDropOrDiscontinuity(clampDebt)

if debtDecision is discontinuity:
  resynchronize state and clocks
  previous = valueCopy(current)
  accumulator = 0
  clear separate debt state
  invalidate dependent history

assert 0 <= accumulator < fixedStep
alpha = accumulator / fixedStep
presentationTime = max(0, simulationTime - fixedStep + accumulator)
presented = interpolate(previous, current, alpha)
```

Admit finite nonnegative raw delta, positive fixed step and a finite substep
budget before arithmetic. Increment `substeps` on each executed step. Keep
integer tick identity separate from accumulated floating seconds; long runs
need a declared roundoff/epoch policy rather than a new epsilon at each gate.

Debt accounts for complete unprocessed steps outside the interpolation
accumulator plus time excluded by raw-delta clamping. Every excluded interval is
recorded as scheduled catch-up, an explicit authoritative-time drop, or a
discontinuity; it never disappears silently. Dropping time or scheduling debt
does not itself reset history when the same dropped interval is removed from the
shared timeline and all coupled analytic motion uses the resulting delayed
presentation time. Skipping an interval while advancing that timeline is a
discontinuity and resets the state pair, clocks, and dependent history
explicitly.

The pair brackets presentation time. If analytic and recurrent actors share a
shot, either sample both at the deliberately delayed presentation time or
perform an explicit resynchronization after debt handling. Sampling analytic
motion from wall time while recurrence drops time causes visible phase drift.

`THREE.Timer` connects once to the document, updates from the timestamp passed
to `renderer.setAnimationLoop()`, and supplies delta to this one policy. A
timer timestamp is milliseconds in the same performance-clock epoch as
construction; its delta and elapsed queries return seconds. Hidden updates
report zero delta and leave elapsed unchanged, and becoming visible resets the
current reference time. This is active-time suppression, not evidence of the
raw hidden interval. Record that interval separately when the debt policy
needs it. `reset() does not zero elapsed` or the already queried delta; it
resets the current sample reference. Semantic time reset belongs to the motion
owner. Connect once (disconnect before reconnecting), dispose the listener,
and apply time scaling once; external replay clocks should supply their own
deltas rather than mixing a synthetic epoch with Timer visibility callbacks. A
simulation owner may provide its own cadence; in that branch the render loop
requests presentation but never advances the coupled state.

### Recurrent response

A second-order spring makes velocity part of semantic state:

```text
acceleration = (target - position) * stiffness - velocity * damping
velocity += acceleration * fixedStep
position += velocity * fixedStep
```

The coefficients above are mass-normalized; stiffness has units `s^-2` and
damping `s^-1`. A physical spring with force coefficients divides by mass.
Choose the fixed step through stability analysis and step-halving over the full
stiffness/damping envelope. A finite terminal-lock sequence copies the exact
terminal pose and zeros relative linear/angular velocity in the declared lock
frame; a finite hand-off preserves its
declared terminal pose and velocity. Residual spring drift satisfies neither
contract. A periodic sequence wraps with declared phase/state continuity. An
open-ended sequence follows its declared external stop/reset transition without
imposing a generic terminal pose or zero-velocity rule.

For perceptual response, author retention per second:

```text
alpha = 1 - pow(retentionPerSecond, dt)
value = lerp(value, target, alpha)
```

For finite `0 < retentionPerSecond <= 1`, use
`alpha = -expm1(dt * log(retentionPerSecond))` to preserve tiny increments;
validate `dt>=0`, return unchanged state for zero duration, and treat zero
retention as an explicit instantaneous rule for positive duration. A shader
without `expm1` needs a bounded small-argument approximation or precomputed
uniform, not an invented API. The increment form is `value += (target-value)*alpha`.

This update is cadence-invariant only when target history is held or integrated
consistently over each processed interval; it is not a physical integrator.
Define how the target exists between timestamps:

- **continuous:** integrate the exponential-response equation against the known
  target function over the interval, or state and gate the error of the declared
  sampling phase;
- **zero-order hold:** keep each timestamped target until the next timestamp and
  split a render interval at every target change;
- **interpolated samples:** interpolate timestamped samples by the declared rule
  and integrate or converge against that same continuous reconstruction.

Verify 30, 60, 120, and 240 Hz against the same underlying target, not four
different per-frame sample lists. For a held target, the checkpoint reference is

```text
value(T) = target + (value(0) - target) * retentionPerSecond^T
```

For time-varying targets, compare shared wall-time checkpoints with the analytic
integral when available; otherwise run a cadence-refinement convergence gate
against the declared target reconstruction and sampling phase.

### Replay and clip ownership

Persistent state contains only semantic values:

```text
phaseId, phaseLocalTime
position, velocity
baseQuaternion, angularVelocity, spinAngle
stableActorId, generation
seed, rngCounter, oneShotEventFlags
```

The same seed, counter start, event schedule, initial buffers, and fixed step
must reconstruct the same state at matched authoritative times at every
presentation rate. A finite branch must also reconstruct its terminal state;
periodic and open-ended branches verify their wrap or stop/reset contract.
Reset all semantic state atomically when that contract calls for reset.

`AnimationMixer` consumes the same time policy: use `mixer.update(fixedStep)`
for simulation-owned clips and `mixer.setTime(authoritativeTime)` for seeking.
In r185, `setTime() is not a complete replay`: it zeros mixer/action times and
then calls `update(time)`, multiplying by mixer `timeScale`. It does not
restore finished/disabled/paused action state, prior loop count, scheduled
starts, fade/warp schedules, or one-shot side effects. Define a reset/replay
recipe for the admitted action set, restore its loop/weight/time-scale policy,
and reconstruct schedules from the same semantic event log. Use a unit mixer
scale for an already scaled authoritative clock, or invert the admitted nonzero
scale explicitly. Calling reset/play on every frame is not a seeking solution.
Idempotent event application separates replayed state from external side effects.
See [AnimationMixer](https://github.com/mrdoob/three.js/blob/r185/src/animation/AnimationMixer.js)
and [Timer](https://github.com/mrdoob/three.js/blob/r185/src/core/Timer.js).
Assign channels explicitly, for example skeletal pose to the clip, root
transform to procedural motion, and camera transform to the camera rig.

## r185 representation and GPU residency

### API and residency

In r185, `BatchedMesh` improves scene/state management but visible multi-draw
entries remain separate backend draw items. It is not an instanced one-draw
bucket.

Use these exact API homes:

| Need | API |
| --- | --- |
| renderer, timer, storage attributes, pipeline | `three/webgpu` |
| `Fn`, `instanceIndex`, `mix`, `positionLocal`, `storage`, `uniform`, vectors | `three/tsl` |
| repeated instance state | `StorageInstancedBufferAttribute` |
| general/static compute state | `StorageBufferAttribute` |
| compute submission | `renderer.compute()` |

Split immutable parameters from hot state. A compact recurrent slot normally
contains previous/current position, velocity, quaternion, angular velocity,
phase, seed/counter, flags, and stable identity generation. Keep two pose slots:
compute writes the next state; vertex TSL reads previous/current and blends by
the CPU-owned `alpha`.

```ts
import * as THREE from 'three/webgpu';
import { instanceIndex, mix, positionLocal, storage, uniform } from 'three/tsl';

const previous = new THREE.StorageInstancedBufferAttribute( capacity, 4 );
const current = new THREE.StorageInstancedBufferAttribute( capacity, 4 );
const previousNode = storage( previous, 'vec4', capacity );
const currentNode = storage( current, 'vec4', capacity );
const alphaNode = uniform( 0 );

material.positionNode = positionLocal.add(
  mix(
    previousNode.element( instanceIndex ).xyz,
    currentNode.element( instanceIndex ).xyz,
    alphaNode
  )
);
```

Independent per-slot catch-up may fuse fixed steps inside one invocation.
Collision, constraints, scans, compaction, and bounds with global dependencies
remain ordered dispatches; workgroup barriers do not create a global barrier.

`computeAsync()` waits for renderer initialization before enqueueing compute;
it does not prove CPU-visible GPU completion. CPU-visible validation requires an
explicit asynchronous copy/map after the submitted work. Keep readback outside
the frame-critical loop.

Treat workgroup size as target-tuned. Measure CPU update/upload and GPU dispatch
p50/p95, active/visible count, aligned hot-state bytes, and presentation error.
Add culling or compaction only when removed work exceeds its dispatch and
traffic cost. Slot reuse increments generation before the new actor becomes
visible.

## Analytic phases, launch, and stage release

### Phase state

Store named boundaries and phase-local time rather than one opaque normalized
timeline. Derive every later boundary from earlier durations so changing one
duration cannot silently overlap or skip a phase. One-shot events record event
time, actor identity, phase, seed, and RNG counter.

For a three-part scalar distance curve with a constant slow phase followed by
constant acceleration and terminal deceleration, solve continuity rather than
repeatedly lerping toward the endpoint:

```text
slowSpeed = slowDistance / slowDuration
remaining = totalDistance - slowDistance

acceleration =
  (remaining - slowSpeed * (accelDuration + 0.5 * decelDuration))
  / (0.5 * accelDuration * (accelDuration + decelDuration))

peakSpeed = slowSpeed + acceleration * accelDuration
deceleration = peakSpeed / decelDuration
```

Integrate each segment analytically and verify position/speed continuity at
both boundaries. Require finite positive durations and a feasible distance/velocity
envelope before division; a negative solved acceleration violates a stated
accelerating phase. Declare the acceleration jumps this piecewise curve permits.
Use Hermite or quintic segments when endpoint velocity or
acceleration constraints differ.

### Curved launch frame

For a path around a spherical body, derive basis and velocity from the authored
trajectory:

```text
arcAngle = groundArcDistance / bodyRadius
radial  = normalize(0, cos(arcAngle), -sin(arcAngle))
tangent = normalize(0, -sin(arcAngle), -cos(arcAngle))

position = bodyCenter + radial * (bodyRadius + altitude) + crossrange
velocity = bodyCenterVelocity
         + altitudeDot * radial
         + (bodyRadius + altitude) * arcAngleDot * tangent
         + crossrangeDot
```

The displayed basis is fixed and `bodyRadius` constant. A rotating body frame
adds its angular transport term and changes every basis derivative; a changing
radius adds its radial rate. Declare crossrange in one frame and differentiate
that mapping too. When velocity vanishes, retain the declared orientation or
use a separately authored tangent, rather than normalizing zero.
Align the model's declared forward/up axis to the differentiated velocity, then
apply authored roll as a separate quaternion in the stated local/world order.
A radial/tangent blend is not the path derivative and may point off-trajectory.
Keep object vibration, camera shake, trajectory, and physical state as separate
channels.

### Detachment and release

Capture the child's world transform before changing ownership. After
reparenting, compute its new local transform as described in the moving-frame
section. The release state inherits the parent's point velocity:

```text
v_release = v_parent_origin + omega_parent cross r_world
          + R_parent * v_local + v_authored_separation
```

The formula assumes rigid parent motion and parent-local coordinate velocity
`v_local`, including any pre-release peel derivative. For `x_world=o+A*x_local`,
use the full derivative `oDot + ADot*x_local + A*xLocalDot` under changing scale
or affine motion. The child angular velocity similarly combines parent motion
with its relative angular motion in the declared frame. Velocity offsets are
not impulses; a physical impulse uses the authoritative mass/inertia owner.
Use seeded variation around declared separation axes. For a closed-form peel,
evaluate attachment-local displacement until the release event:

```text
peelT = smoothstep(peelStart, detachTime, authoritativeTime)
localOffset = outwardAxis * maxPeelDistance * peelT^2
```

After release, advance the detached semantic actor or GPU slot. Many released
actors split static anchors/material variants from hot pose/velocity state.

## Moving frames, docking, and quaternions

### Frame rules

Name world, actor-local, orbital radial/tangent, docking-axis, rotating-parent,
and camera-presentation frames where used. A physical vector changes basis by
rotation (and scale for render units). A coordinate rate in a moving frame is a
different quantity and includes origin and `omega cross r` transport terms.

Docking error is evaluated in the current docking frame:

```text
offset = actorPosition - dockPort
axial = dot(offset, dockAxis)
radialVector = offset - dockAxis * axial
radialDistance = length(radialVector)
radialDirection = normalizeOrFallback(radialVector, previousRadialDirection)
```

Recompute the dock port and axis after the target rotates. Blend axial and
radial errors independently. Admit a finite unit docking axis and preserve its
orientation convention. At a terminal lock set the exact port-relative pose
and zero relative velocity, not zero world velocity: the actor inherits the
port point velocity and angular motion. A stationary world target is the
special case where those inherited rates are zero. Align the actor's declared docking axis,
then compose local spin or world roll in the stated order. The fallback
direction makes on-axis docking finite.

### Quaternion operations

Declare helpers in frame terms:

```text
alignmentThenWorldRoll(base, worldRoll): result = worldRoll * base
localSpinAfterBase(base, localSpin):      result = base * localSpin
worldAngularVelocity(q, omega, dt):       q = deltaWorld(omega, dt) * q
```

In Three.js:

```text
worldRoll * base       -> result.multiplyQuaternions(worldRoll, base)
base * localSpin       -> result.multiplyQuaternions(base, localSpin)
deltaWorld * q         -> q.premultiply(deltaWorld).normalize()
```

Normalize input axes. Nearly parallel alignment returns identity; nearly
antiparallel alignment selects a stable perpendicular axis. Before storing or
interpolating consecutive quaternions on a shortest-path branch, negate the
new quaternion when their dot product is negative so the double cover does
not create a jump. Three.js `slerp` selects that short orientation path; endpoint
quaternions alone cannot encode full revolutions or a declared long arc. Keep
an unwrapped angle/axis or winding-aware multi-key path for those branches;
unconditional sign canonicalization must not erase its semantic turns.
Validate `abs(length(q) - 1)` against a declared tolerance.

### Reparenting without a jump

Update the old and new parent world matrices, capture `M_world_old`, then solve:

```text
M_local_new = inverse(M_world_newParent) * M_world_old
```

Require finite, nonsingular and sufficiently conditioned parent matrices before
inversion; an inverse routine returning a zero matrix does not make the handoff
valid. Reject hierarchy cycles and update all affected ancestors first.
`Object3D.attach()` is valid for compatible scale chains. Non-uniform ancestry
may introduce shear; accept TRS decomposition only when recomposition residual
passes. Otherwise preserve the full affine local matrix with
`matrixAutoUpdate = false`, introduce an affine wrapper/bake, or reject the
handoff. Verify the world matrix before and after, not only position.

## Environment-driven actors

Before implementing this branch, declare each exchanged quantity's units,
frame/origin, timestamp or interval, cadence and sample phase,
producer/consumer ownership and publication order, resource/state version,
validity and error bounds, and reset behavior. Motion owns the actor pose; the
environment owner supplies samples or accepts reactions at those declared
instants and intervals.

| Observable | Motion model | Reaction scope |
| --- | --- | --- |
| scripted actor following a surface | analytic path plus filtered height/normal response | one-way, presentation-authored |
| visible inertia or drift | fixed-step actor with distributed force samples | one-way only with a bounded omitted-feedback regime |
| displacement or load-dependent wake | coupled environment/body solver | two-way source and reaction |
| metric slamming, added mass, radiation/diffraction, or control loads | dedicated domain solver | consume its pose through an explicit adapter |

Request samples at the actor's physical support scale. Keep interface geometry
velocity distinct from material transport velocity: height/normal following
uses the former; drag uses material-relative velocity. Missing channels remain
missing and either disable that term or select a declared reduced model.

For a distributed hydrostatic approximation, each validated cell may contribute:

```text
g_up = -g / |g|
immersion_i = dot(surfacePoint_i - samplePoint_i, g_up)
submergedVolume_i, buoyancyCentroid_i = submergedProperties_i(immersion_i)
F_buoyancy_i = density_i * |g| * submergedVolume_i * g_up
v_body_i = v_center + omega_body cross (samplePoint_i - center)
v_relative_i = v_body_i - materialCurrent_i
F_drag_i = -0.5 * density_i * C_d_i * area_i * |v_relative_i| * v_relative_i
torque_i = (buoyancyCentroid_i - center) cross F_buoyancy_i
         + (samplePoint_i - center) cross F_drag_i
```

`buoyancyCentroid_i` is the centroid of cell `i`'s submerged volume at the
current immersion, returned by the same validated hull-cell approximation as
`submergedVolume_i` and expressed in the stable physics frame. `samplePoint_i`
is the declared drag quadrature point in that frame. A dry cell contributes zero
buoyancy force and torque without evaluating a nonexistent submerged centroid.
Admit finite positive density and a finite nonzero gravity norm for this
hydrostatic model, with finite nonnegative drag coefficient, area and cell
volume. A zero-gravity branch needs its own model instead of division by zero.
This approximation needs step-halving and sample-layout refinement. Surface
parameterization velocity is not material current; substituting it creates
wave-phase drift.

A two-way interval orders prediction, common-time sampling, source creation,
conservative scatter, environment advance, reaction reduction, actor
correction, conservation/stability checks, and atomic publication. Declare rate
versus interval-integrated semantics once. Keep the coupled hot state on one
side of the CPU/GPU boundary or use a latency-bounded service; synchronous
frame-loop readback is outside the valid route.

## Presentation, resets, output, and lifecycle

### Immutable presentation pair

Publish previous/current pose generations with independent timestamps and the
same stable actor identity. Presentation interpolates this pair; transforms,
motion vectors, bounds, shadows, and temporal effects consume it without
resampling live simulation state. Keep the previous presented pose and camera
separate from the simulation pair: motion vectors compare two presented
samples, including their interpolation fractions, not two fixed ticks.
Resource reuse waits until all consumers of a
generation are complete.

Every discontinuity chooses a scoped history action:

| Discontinuity | Required action |
| --- | --- |
| camera cut or teleport | reset affected motion-vector and temporal history |
| spawn/despawn or storage-slot reuse | change stable identity generation; reject cross-identity velocity |
| reparent or frame/origin change | publish both frame mappings or reset affected history |
| topology, deformation, or LOD change | migrate only with a defined correspondence; otherwise reset |
| abrupt quality/state representation change | project both pose states with bounded error or reset |

A semantic motion reset clears phase/event state, accumulator and debt records,
seeds/counters, previous/current buffers, and finite terminal locks together. A
temporal-only reset, such as a camera cut, clears affected presentation history
without changing semantic motion. A debt drop or scheduled catch-up without a
discontinuity preserves history. Either reset publishes a valid zero/unknown
motion vector rather than a large derived velocity.

### Output and resource ownership

Animation data textures, pose buffers, masks, and lookup tables use
`NoColorSpace`; encoded sRGB albedo uses `SRGBColorSpace`, while other color
inputs declare their actual encoding. HDR working buffers remain linear.
Use node materials for vertex/instance motion. A node-post app renders through
`RenderPipeline` and has one tone-map/output conversion owner,
`outputColorTransform` or explicit `renderOutput()`.

Disposal stops the animation loop and releases owned listeners, timers, storage
attributes/buffers, compute resources, validation readback staging, materials,
geometry, and pipeline resources. Reset preserves reusable allocations;
disposal relinquishes ownership.

## Failure signatures and verification

### Diagnose visible wrongness

| Symptom | Likely cause | Check |
| --- | --- | --- |
| terminal pose changes with display Hz | render delta entered semantic state | replay with one fixed schedule at four presentation rates |
| analytic actor separates after a hidden-tab stall | analytic clock ignored recurrent debt policy | compare timeline and simulation/presentation time after clamp |
| orientation takes a long arc or flips | quaternion signs differ across the double cover | log consecutive dot products before interpolation |
| NaN on an aligned or opposite axis | zero/antiparallel fallback absent | exercise both degenerate alignment inputs |
| detached child jumps | old world matrix used as new local matrix | compare complete world matrices around reparenting |
| detached part lacks readable tangential motion | rotating-parent `omega cross r` omitted | compare release velocity with analytic transport term |
| finite docked actor creeps | terminal lock retained port-relative motion | inspect exact port-relative pose and inherited world point/angular velocity |
| instance reads another actor's phase | stride, slot generation, or identity mismatch | validate selected slots outside the frame loop |
| history streaks after teleport or slot reuse | validity epoch was preserved incorrectly | inspect reset scope and stable identity generation |
| CPU stalls on GPU motion | frame-critical map/readback | count copies/maps on the frame path |

### Verification matrix

For every selected branch, record thresholds and direct evidence:

- analytic: direct seek equals replay at phase boundaries, matched checkpoints,
  and finite terminal time when the branch has one;
- recurrent: step-halving passes over the authored parameter envelope;
- perceptual: 30, 60, 120, and 240 Hz consume one declared target signal and
  agree at shared wall-time checkpoints within the branch's analytic or
  convergence tolerance;
- duration: finite motion reaches its exact pose and declared velocity/hand-off,
  with zero relative velocity in the declared terminal-lock frame; periodic motion
  preserves phase/wrap continuity; open-ended motion obeys its stop/reset
  transition without a fabricated terminal state;
- frames: zero-length and antiparallel inputs stay finite, quaternion norm and
  sign continuity pass, and reparenting preserves the world matrix;
- identity: spawn/despawn, slot reuse, topology/LOD, teleport, reparent, and cut
  select the intended reset or migration;
- GPU: named dispatch order, storage layout/bytes, p50/p95 timing, selected-slot
  snapshots outside the frame loop, and zero frame-critical readbacks;
- environment: sample support and timing pass; one-way leaves the source
  unchanged within its claim, or two-way closes declared force/torque/work
  residuals;
- presentation: pose, motion vectors, bounds, shadows, and temporal consumers
  resolve one immutable pair and one output owner;
- lifecycle: replay reset restores all semantic state and disposal releases
  every owned resource.
